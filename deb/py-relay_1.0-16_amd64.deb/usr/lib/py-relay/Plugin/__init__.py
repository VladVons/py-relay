'''
Copyright:   (c) 2017, Vladimir Vons, UA
Author:      Vladimir Vons <VladVons@gmail.com>
Created:     2017.10.22
License:     GNU, see LICENSE for more details

Description:
this file indicates that directory is mdule
'''

